import 'dart:io';
import 'package:http/http.dart' as http;
import '../state/image_provider.dart';

Future<void> uploadImage(File image, InMemoryImageProvider provider) async {
  try {
    provider.setUploading(true);
    var request = http.MultipartRequest(
      'POST',
      Uri.parse("https://httpbin.org/post"),
    );
    request.files.add(await http.MultipartFile.fromPath('file', image.path));
    var response = await request.send();

    if (response.statusCode == 200) {
      provider.clearImage();
    }
  } catch (e) {
    print("Upload failed: $e");
  } finally {
    provider.setUploading(false);
  }
}
