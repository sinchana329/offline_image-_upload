import 'dart:io';
import 'package:flutter/material.dart';

class InMemoryImageProvider with ChangeNotifier {
  File? _pendingImage;
  bool _isUploading = false;

  File? get pendingImage => _pendingImage;
  bool get isUploading => _isUploading;

  void setImage(File image) {
    _pendingImage = image;
    notifyListeners();
  }

  void clearImage() {
    _pendingImage = null;
    notifyListeners();
  }

  void setUploading(bool value) {
    _isUploading = value;
    notifyListeners();
  }
}
