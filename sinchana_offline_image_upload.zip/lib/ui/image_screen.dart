import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

import '../services/upload_service.dart';
import '../state/image_provider.dart';

class ImageScreen extends StatefulWidget {
  @override
  State<ImageScreen> createState() => _ImageScreenState();
}

class _ImageScreenState extends State<ImageScreen> {
  final picker = ImagePicker();
  late Connectivity _connectivity;

  @override
  void initState() {
    super.initState();
    _connectivity = Connectivity();
    _connectivity.onConnectivityChanged.listen((result) async {
      if (result != ConnectivityResult.none) {
        var provider = Provider.of<InMemoryImageProvider>(
          context,
          listen: false,
        );
        if (provider.pendingImage != null && !provider.isUploading) {
          await uploadImage(provider.pendingImage!, provider);
        }
      }
    });
  }

  Future pickImage() async {
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      File file = File(picked.path);
      var connection = await _connectivity.checkConnectivity();

      var provider = Provider.of<InMemoryImageProvider>(context, listen: false);
      if (connection != ConnectivityResult.none) {
        await uploadImage(file, provider);
      } else {
        provider.setImage(file);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    var provider = Provider.of<InMemoryImageProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text('Offline Image Upload')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          provider.pendingImage != null
              ? Image.file(provider.pendingImage!, height: 200)
              : Icon(Icons.image, size: 100, color: Colors.grey),
          SizedBox(height: 20),
          provider.isUploading
              ? CircularProgressIndicator()
              : Text(
                provider.pendingImage != null
                    ? "Pending upload"
                    : "No image selected",
              ),
          SizedBox(height: 20),
          ElevatedButton(onPressed: pickImage, child: Text("Select Image")),
        ],
      ),
    );
  }
}
