import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'ui/image_screen.dart';
import 'state/image_provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => InMemoryImageProvider(),
      child: MaterialApp(home: ImageScreen()),
    ),
  );
}
