# 📱 Flutter Offline Image Upload App

## ✅ Features
- Pick image from gallery even when offline
- Store image in memory (RAM)
- Auto-upload when internet is restored
- Uploads to a mock API (httpbin.org)

## 📦 Packages Used
- `image_picker`
- `connectivity_plus`
- `provider`
- `http`

## 🚀 How to Run
1. Download the project or clone repo
2. Run `flutter pub get`
3. Connect Android device or run emulator
4. Run using: `flutter run`

## 📂 Folder Structure
lib/
├── main.dart
├── ui/
│ └── image_screen.dart
├── services/
│ └── upload_service.dart
├── state/
│ └── image_provider.dart