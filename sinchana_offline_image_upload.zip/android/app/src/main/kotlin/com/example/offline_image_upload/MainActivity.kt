package com.example.offline_image_upload

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
